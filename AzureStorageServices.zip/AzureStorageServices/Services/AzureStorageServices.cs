﻿using Azure; 
using Azure.Storage.Blobs;
using Azure.Data.Tables;
using Azure.Storage.Queues;
using Azure.Storage.Files.Shares;
using Microsoft.AspNetCore.Mvc;
using ABCRetailers.Models;
using ABCRetailers.Services;
using System.ComponentModel.DataAnnotations; 
using Microsoft.Extensions.Logging;
using System.Linq; 

namespace ABCRetailers.Services
{
    public class AzureStorageService : IAzureStorageService
    {
        private readonly string _connectionString;
        private readonly ILogger<AzureStorageService> _logger;

        public AzureStorageService(IConfiguration configuration, ILogger<AzureStorageService> logger)
        {
            _connectionString = configuration.GetConnectionString("AzureStorageConnectionString");
            _logger = logger;
        }

        public async Task<List<Customer>> GetCustomersAsync()
        {
            var tableClient = new TableClient(_connectionString, "customers");
            await tableClient.CreateIfNotExistsAsync();
            var customers = new List<Customer>();
            await foreach (var customer in tableClient.QueryAsync<Customer>())
            {
                customers.Add(customer);
            }
            return customers;
        }

        public async Task<Customer> GetCustomerAsync(string rowKey)
        {
            var tableClient = new TableClient(_connectionString, "customers");
            var response = await tableClient.GetEntityAsync<Customer>("Customer", rowKey);
            return response.Value;
        }

        public async Task<Customer> AddCustomerAsync(Customer customer)
        {
            var tableClient = new TableClient(_connectionString, "customers");
            await tableClient.CreateIfNotExistsAsync();

            if (string.IsNullOrEmpty(customer.RowKey))
                customer.RowKey = Guid.NewGuid().ToString();
            if (string.IsNullOrEmpty(customer.PartitionKey))
                customer.PartitionKey = "Customer";

            await tableClient.AddEntityAsync(customer);
            return customer;
        }

        public async Task<Customer> UpdateCustomerAsync(Customer customer)
        {
            var tableClient = new TableClient(_connectionString, "customers");
            await tableClient.UpdateEntityAsync(customer, ETag.All, TableUpdateMode.Replace);
            return customer;
        }

        public async Task<bool> DeleteCustomerAsync(string rowKey)
        {
            var tableClient = new TableClient(_connectionString, "customers");
            await tableClient.DeleteEntityAsync("Customer", rowKey);
            return true;
        }


        public async Task<List<Product>> GetProductsAsync()
        {
            var tableClient = new TableClient(_connectionString, "products");
            await tableClient.CreateIfNotExistsAsync();

            var products = new List<Product>();
            await foreach (var product in tableClient.QueryAsync<Product>())
            {
                products.Add(product);
            }
            return products;
        }

        public async Task<Product> GetProductAsync(string rowKey)
        {
            var tableClient = new TableClient(_connectionString, "products");
            await tableClient.CreateIfNotExistsAsync();

            var product = await tableClient.GetEntityAsync<Product>("Product", rowKey);
            return product.Value;
        }

        public async Task<Product> AddProductAsync(Product product, IFormFile imageFile)
        {
            if (imageFile != null && imageFile.Length > 0)
            {
                var blobServiceClient = new BlobServiceClient(_connectionString);
                var containerClient = blobServiceClient.GetBlobContainerClient("product-images");
                await containerClient.CreateIfNotExistsAsync();

                var blobClient = containerClient.GetBlobClient(imageFile.FileName);
                using (var stream = imageFile.OpenReadStream())
                {
                    await blobClient.UploadAsync(stream, true);
                }
                product.ImageUrl = blobClient.Uri.ToString();
            }

            var tableClient = new TableClient(_connectionString, "products");
            await tableClient.CreateIfNotExistsAsync();

            if (string.IsNullOrEmpty(product.RowKey))
                product.RowKey = Guid.NewGuid().ToString();

            await tableClient.AddEntityAsync(product);
            return product;
        }

        public async Task<Product> UpdateProductAsync(Product product, IFormFile? imageFile)
        {
            var tableClient = new TableClient(_connectionString, "products");

            if (imageFile != null && imageFile.Length > 0)
            {
                var blobServiceClient = new BlobServiceClient(_connectionString);
                var containerClient = blobServiceClient.GetBlobContainerClient("product-images");

                var blobClient = containerClient.GetBlobClient(imageFile.FileName);
                using (var stream = imageFile.OpenReadStream())
                {
                    await blobClient.UploadAsync(stream, true);
                }
                product.ImageUrl = blobClient.Uri.ToString();
            }

            await tableClient.UpdateEntityAsync(product, ETag.All, TableUpdateMode.Replace);
            return product;
        }

        public async Task<bool> DeleteProductAsync(string rowKey)
        {
            try
            {
                var tableClient = new TableClient(_connectionString, "products");
                await tableClient.DeleteEntityAsync("Product", rowKey);
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting product with RowKey: {RowKey}", rowKey);
                return false;
            }
        }
        public async Task<bool> SendMessageAsync(string queueName, string message)
        {
            try
            {
                var queueClient = new QueueClient(_connectionString, queueName);
                await queueClient.CreateIfNotExistsAsync();
                await queueClient.SendMessageAsync(message);
                _logger.LogInformation("Message sent to queue {QueueName}: {Message}", queueName, message);
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to send message to queue {QueueName}", queueName);
                return false;
            }
        }

        public async Task<string> UploadFileAsync(IFormFile file, string shareName, string directoryName)
        {
            var shareClient = new ShareClient(_connectionString, shareName);
            await shareClient.CreateIfNotExistsAsync();

            var directoryClient = shareClient.GetDirectoryClient(directoryName);
            await directoryClient.CreateIfNotExistsAsync();

            var fileClient = directoryClient.GetFileClient(file.FileName);
            using (var stream = file.OpenReadStream())
            {
                await fileClient.CreateAsync(stream.Length);
                await fileClient.UploadRangeAsync(new Azure.HttpRange(0, stream.Length), stream);
            }
            return $"File '{file.FileName}' uploaded successfully to {shareName}/{directoryName}";
        }
    }
}