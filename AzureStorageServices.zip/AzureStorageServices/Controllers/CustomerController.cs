﻿using ABCRetailers.Models;
using ABCRetailers.Services;
using Azure.Data.Tables;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Configuration;

namespace ABCRetailers.Controllers
{
    public class CustomerController : Controller
    {
        private readonly IAzureStorageService _storageService;

        public CustomerController(IAzureStorageService storageService)
        {
            _storageService = storageService;
        }

        public async Task<IActionResult> Index()
        {
            var customers = await _storageService.GetCustomersAsync();
            return View(customers);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Customer customer)
        {
            //if (ModelState.IsValid)
            //{
                customer.RowKey = Guid.NewGuid().ToString();
                customer.PartitionKey = "Customer";

                await _storageService.AddCustomerAsync(customer);
                await _storageService.SendMessageAsync("processed-items", $"Created customer: {customer.Name}");

                return RedirectToAction(nameof(Index));
            }

            //return View(customer);
        //}

        public async Task<IActionResult> Edit(string id)
        {
            var customer = await _storageService.GetCustomerAsync(id);
            if (customer == null)
            {
                return NotFound();
            }
            return View(customer);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(string id, Customer customer)
        {
            if (id != customer.RowKey)
            {
                return NotFound();
            }

            // if (ModelState.IsValid)
            // {
            var existingCustomer = await _storageService.GetCustomerAsync(id);

            customer.Username = existingCustomer.Username;
            customer.ShippingAddress = existingCustomer.ShippingAddress; 
            customer.PartitionKey = existingCustomer.PartitionKey;
            customer.Timestamp = existingCustomer.Timestamp;         
            customer.ETag = existingCustomer.ETag;                 

            await _storageService.UpdateCustomerAsync(customer);
            await _storageService.SendMessageAsync("processed-items", $"Updated customer: {customer.Name} {customer.Surname}");
            return RedirectToAction(nameof(Index));
            // }
            // return View(customer);
        }

        public async Task<IActionResult> Delete(string id)
        {
            var customer = await _storageService.GetCustomerAsync(id);
            if (customer == null)
            {
                return NotFound();
            }
            return View(customer);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            await _storageService.DeleteCustomerAsync(id);
            await _storageService.SendMessageAsync("processed-items", $"Deleted customer with ID: {id}");
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> TestConnection()
        {
            try
            {
                var customers = await _storageService.GetCustomersAsync();
                return Content("Azure Table Storage connection successful! Service is working.");
            }
            catch (Exception ex)
            {
                return Content($"Connection failed: {ex.Message}");
            }
        }

        public async Task<IActionResult> Details(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                return NotFound();
            }

            var customer = await _storageService.GetCustomerAsync(id);

            if (customer == null)
            {
                return NotFound();
            }

            return View(customer);
        }
    }
}