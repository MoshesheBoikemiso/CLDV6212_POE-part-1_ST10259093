﻿using ABCRetailers.Models;
using ABCRetailers.Services;
using Microsoft.AspNetCore.Mvc;

namespace ABCRetailers.Controllers
{
    public class ProductController : Controller
    {
        private readonly IAzureStorageService _storageService;

        public ProductController(IAzureStorageService storageService)
        {
            _storageService = storageService;
        }

        public async Task<IActionResult> Index()
        {
            var products = await _storageService.GetProductsAsync();
            return View(products);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Product product, IFormFile imageFile)
        {
            //if (ModelState.IsValid)
            //{
                await _storageService.AddProductAsync(product, imageFile);
                await _storageService.SendMessageAsync("processed-items", $"Created new product: {product.ProductName}");
                return RedirectToAction(nameof(Index));
            //}
            //return View(product);
        }

        public async Task<IActionResult> Edit(string id)
        {
            var product = await _storageService.GetProductAsync(id);
            if (product == null)
            {
                return NotFound();
            }
            return View(product);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, Product product, IFormFile? imageFile)
        {
            if (id != product.RowKey)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                await _storageService.UpdateProductAsync(product, imageFile);
                await _storageService.SendMessageAsync("processed-items", $"Updated product: {product.ProductName}");
                return RedirectToAction(nameof(Index));
            }
            return View(product);
        }

        public async Task<IActionResult> Delete(string id)
        {
            var product = await _storageService.GetProductAsync(id);
            if (product == null)
            {
                return NotFound();
            }
            return View(product);
        }

        [HttpPost, ActionName("Delete")]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            await _storageService.DeleteProductAsync(id);
            await _storageService.SendMessageAsync("processed-items", $"Deleted product with ID: {id}");
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Details(string id)
        {
            var product = await _storageService.GetProductAsync(id);
            if (product == null)
            {
                return NotFound();
            }
            return View(product);
        }
    }
}